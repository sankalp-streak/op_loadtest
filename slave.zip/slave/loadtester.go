package main

import (
	"fmt"
	"io/ioutil"
	"os/exec"
	"strconv"
	"strings"
	"sync"
)

type statusmap struct {
	mu            sync.Mutex
	statusCodeMap map[string]int32
}

var stmp = statusmap{statusCodeMap: map[string]int32{}}

func printDetails() {
	fmt.Println("Results✅✅✅")
	fmt.Println("200-299 =>", stmp.statusCodeMap["200-299"])
	fmt.Println("300-399 =>", stmp.statusCodeMap["300-399"])
	fmt.Println("400-499 =>", stmp.statusCodeMap["400-499"])
	fmt.Println("500-599 =>", stmp.statusCodeMap["500-599"])
	fmt.Println("Unknown =>", stmp.statusCodeMap["Unknown"])
}

func statusCode(output string) int {
	// Find and extract the HTTP status code from the response headers
	lines := strings.Split(output, "\n")
	for _, line := range lines {
		if strings.HasPrefix(line, "HTTP/") {
			parts := strings.Fields(line)
			if len(parts) > 1 {
				statusCode, err := strconv.Atoi(parts[1])
				if err != nil {
					statusCode = -1
				}
				return statusCode
				/*
					stmp.mu.Lock()
					stmp.statusCodeMap[getStatusRange(statusCode)]++
					stmp.mu.Unlock()
					wg.Done()
				*/
				break
			}
		}
	}
	return 0
}

func getStatusRange(statusCode int) string {
	if statusCode >= 200 && statusCode < 300 {
		return "200-299"
	} else if statusCode >= 300 && statusCode < 400 {
		return "300-399"
	} else if statusCode >= 400 && statusCode < 500 {
		return "400-499"
	} else if statusCode >= 500 && statusCode < 600 {
		return "500-599"
	} else {
		return "Unknown"
	}
}

func required(s string) bool {

	nots := []string{
		"open-v2.streak.ninja/_next/static",
		"curl 'https://open-v2.streak.ninja/home'",
		"https://www.googletagmanager.com/'",
		"fonts.googleapis.com",
		"facebook",
		"os-analytics",
		"www.google.co.in",
		"www.googletagmanager.com",
		"data:image/gif",
		"streak.ninja/logo3.ico",
		"/manifest.json",
		"data:image/",
		"_next/static",
		"blog.streak.tech",
		"treak-public-assets",
		"chrome-extension",
		"streak_192.png",
		"analytics.google",
		"streak.ninja/home/strategies",
		"refapi.streak.tech",
		"wss://ss-op.st",
		"nt-op.streak.tech",
	}

	for _, n := range nots {
		if strings.Contains(s, n) {
			return false
		}
	}
	return true

}

func removeEmptyStrings(slice []string) []string {
	var result []string
	for _, str := range slice {
		trimmedStr := strings.TrimSpace(str)
		if trimmedStr != "" {
			result = append(result, trimmedStr)
		}
	}
	return result
}

func cleanCurls(curls []string) []string {
	var filteredCurls []string
	for _, c := range curls {
		if required(c) {
			c = strings.ReplaceAll(c, "\r", "")
			c = strings.ReplaceAll(c, "curl", "curl -i")
			filteredCurls = append(filteredCurls, strings.TrimSpace(c))
		}
	}
	filteredCurls = removeEmptyStrings(filteredCurls)
	return filteredCurls

}

func getCurls(s string) []string {
	// Read the content of the file
	fileContent, err := ioutil.ReadFile(s)
	if err != nil {
		fmt.Println("Error reading file:", err)
		return []string{}
	}

	fileContent = []byte(strings.ReplaceAll(string(fileContent), "--compressed ;", "--compressed ; @@Sankalp@@"))
	curls := strings.Split(string(fileContent), " @@Sankalp@@")
	curls = cleanCurls(curls)
	return curls

}

var mp = map[string]int{}

func hitTarget(curlRequest string) {
	wg.Add(1)
	defer wg.Done()
	cmd := exec.Command("sh", "-c", curlRequest) // Create a new Cmd struct to run the cURL command
	op, err := cmd.Output()                      // Execute the cURL command
	if err != nil {
		fmt.Println("Error executing cURL:", err)
		return
	}
	st := statusCode(string(op))
	r.mu.Lock()
	if st >= 200 && st <= 299 {
		r.suc++
		r.Total++
	} else {
		r.fail++
		r.Total++
	}
	r.mu.Unlock()

}

var start = 0
var complete = 0

var loggedOut []string
var loggedin []string
var bahutSara []string
var multiSearch []string

func load() {

	//loggedOut = getCurls("curls/loggedout.sh")
	//loggedin = getCurls("curls/login.sh")
	//bahutSara = getCurls("curls/common.sh")
	multiSearch = getCurls("slave/curls/multisearch.sh")
	fmt.Println(len(multiSearch))
	for a, b := range mp {
		fmt.Println(a, b)
	}

	//hitTargets(curls)

}
