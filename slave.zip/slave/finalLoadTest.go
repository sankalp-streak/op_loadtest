package main

import (
	"fmt"
	"math/rand"
	"strings"
	"sync"
	"time"
)

type ress struct {
	mu    sync.Mutex
	suc   int32
	fail  int32
	Total int32
}

var r ress

func shuffleStrings(input []string) []string {
	rand.Seed(time.Now().UnixNano()) // Seed the random number generator with the current time

	shuffled := make([]string, len(input))
	copy(shuffled, input)

	// Fisher-Yates shuffle algorithm
	for i := len(shuffled) - 1; i > 0; i-- {
		j := rand.Intn(i + 1)
		shuffled[i], shuffled[j] = shuffled[j], shuffled[i]
	}

	return shuffled
}

func flowTest(curls []string) {

	for i := 0; i < len(curls); i++ {
		hitTarget(curls[i])
		// Check if it's the 10th iteration
		if i%10 == 0 {
			time.Sleep(500 * time.Millisecond)
		}
	}
}

func flowTester(users int) {
	curls := getCurls("curls/loggedout.sh")
	curls = append(curls, getCurls("curls/login.sh")...)
	curls = append(curls, shuffleStrings(getCurls("curls/common.sh"))[:200]...)
	r = ress{suc: 0, fail: 0}
	for i := 0; i < users; i++ {
		go flowTest(curls)
	}
}
func multiSeatch(users int) {
	curls := getCurls("curls/multisearch.sh")
	l := len(curls)
	fmt.Println(len(curls))
	r = ress{suc: 0, fail: 0}
	for i := 0; i < users; i++ {
		randomIndex := rand.Intn(l)
		pick := curls[randomIndex] // get the value from the slice
		go hitTarget(pick)
	}

}

func filterCoreAppStrings(input []string, substring string) []string {
	var filtered []string

	for _, str := range input {
		// Check if the substring is present in the current string
		if strings.Contains(str, substring) {
			filtered = append(filtered, str)
		}
	}

	return filtered
}

func coreAppLoadTest(users int) {
	curls := filterCoreAppStrings(getCurls("curls/common.sh"), "https://api-op.streak.tech/")
	l := len(curls)
	fmt.Println("Total Curls", len(curls))
	r = ress{suc: 0, fail: 0}
	for i := 0; i < users; i++ {
		wg.Add(1)
		randomIndex := rand.Intn(l)
		pick := curls[randomIndex] // get the value from the slice
		go hitTarget(pick)
	}
}

var wg sync.WaitGroup

func finalLoadTest(users int, TestName string) {
	wg = sync.WaitGroup{}
	if TestName == "multisearch" {
		multiSeatch(users)
	} else if TestName == "flow" {
		flowTester(users)
	} else if TestName == "core" {
		coreAppLoadTest(users)
	}
	time.Sleep(5 * time.Second)
	wg.Wait()

}
